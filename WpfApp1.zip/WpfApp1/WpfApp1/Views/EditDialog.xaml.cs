﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Models;

namespace WpfApp1.Views
{
    public partial class EditDialog : Window
    {
        private readonly string tableName;
        private readonly object existingItem;
        private readonly Dictionary<string, TextBox> textBoxes = new Dictionary<string, TextBox>();
        private readonly Dictionary<string, DatePicker> datePickers = new Dictionary<string, DatePicker>();

        public EditDialog(string tableName, object item = null)
        {
            InitializeComponent();
            this.tableName = tableName;
            this.existingItem = item;

            if (item != null)
            {
                Title = "Редактирование записи";
            }
            else
            {
                Title = "Добавление новой записи";
            }

            GenerateForm();
        }

        private void GenerateForm()
        {
            FormPanel.Children.Clear();
            textBoxes.Clear();
            datePickers.Clear();

            switch (tableName)
            {
                case "Users":
                    GenerateUserForm();
                    break;
                case "Bookings":
                    GenerateBookingForm();
                    break;
                case "Locations":
                    GenerateLocationForm();
                    break;
                case "Services":
                    GenerateServiceForm();
                    break;
            }
        }

        private void GenerateUserForm()
        {
            var fields = new Dictionary<string, string>
            {
                {"FullName", "Полное имя"},
                {"Email", "Email"},
                {"Phone", "Телефон"},
                {"Role", "Роль"}
            };

            foreach (var field in fields)
            {
                AddTextField(field.Key, field.Value);
            }

            if (existingItem is User user)
            {
                textBoxes["FullName"].Text = user.FullName ?? "";
                textBoxes["Email"].Text = user.Email ?? "";
                textBoxes["Phone"].Text = user.Phone ?? "";
                textBoxes["Role"].Text = user.Role ?? "";
            }
        }

        private void GenerateBookingForm()
        {
            var fields = new Dictionary<string, string>
            {
                {"UserId", "ID пользователя"},
                {"LocationId", "ID локации"},
                {"TotalGuests", "Количество гостей"},
                {"TotalPrice", "Общая цена"}
            };

            foreach (var field in fields)
            {
                AddTextField(field.Key, field.Value);
            }

            AddDateField("CheckInDate", "Дата заезда");
            AddDateField("CheckOutDate", "Дата выезда");

            if (existingItem is Booking booking)
            {
                textBoxes["UserId"].Text = booking.UserId.ToString();
                textBoxes["LocationId"].Text = booking.LocationId.ToString();
                textBoxes["TotalGuests"].Text = booking.TotalGuests.ToString();
                textBoxes["TotalPrice"].Text = booking.TotalPrice.ToString();
                datePickers["CheckInDate"].SelectedDate = booking.CheckInDate;
                datePickers["CheckOutDate"].SelectedDate = booking.CheckOutDate;
            }
        }

        private void GenerateLocationForm()
        {
            var fields = new Dictionary<string, string>
            {
                {"Name", "Название"},
                {"Region", "Регион"},
                {"Address", "Адрес"},
                {"Price", "Цена"}
            };

            foreach (var field in fields)
            {
                AddTextField(field.Key, field.Value);
            }

            if (existingItem is Location location)
            {
                textBoxes["Name"].Text = location.Name ?? "";
                textBoxes["Region"].Text = location.Region ?? "";
                textBoxes["Address"].Text = location.Address ?? "";
                textBoxes["Price"].Text = location.Price.ToString();
            }
        }

        private void GenerateServiceForm()
        {
            AddTextField("Name", "Название");
            AddTextField("Description", "Описание");

            if (existingItem is Service service)
            {
                textBoxes["Name"].Text = service.Name ?? "";
                textBoxes["Description"].Text = service.Description ?? "";
            }
        }

        private void AddTextField(string name, string label)
        {
            var stackPanel = new StackPanel { Margin = new Thickness(0, 5, 0, 5) };

            var labelControl = new TextBlock
            {
                Text = label + ":",
                Margin = new Thickness(0, 0, 0, 2),
                FontWeight = FontWeights.SemiBold
            };

            var textBox = new TextBox
            {
                Height = 25,
                Name = name
            };

            stackPanel.Children.Add(labelControl);
            stackPanel.Children.Add(textBox);
            FormPanel.Children.Add(stackPanel);

            textBoxes[name] = textBox;
        }

        private void AddDateField(string name, string label)
        {
            var stackPanel = new StackPanel { Margin = new Thickness(0, 5, 0, 5) };

            var labelControl = new TextBlock
            {
                Text = label + ":",
                Margin = new Thickness(0, 0, 0, 2),
                FontWeight = FontWeights.SemiBold
            };

            var datePicker = new DatePicker
            {
                Height = 25,
                Name = name
            };

            stackPanel.Children.Add(labelControl);
            stackPanel.Children.Add(datePicker);
            FormPanel.Children.Add(stackPanel);

            datePickers[name] = datePicker;
        }

        public object GetData()
        {
            switch (tableName)
            {
                case "Users":
                    return GetUserData();
                case "Bookings":
                    return GetBookingData();
                case "Locations":
                    return GetLocationData();
                case "Services":
                    return GetServiceData();
                default:
                    return null;
            }
        }

        private User GetUserData()
        {
            var user = existingItem as User ?? new User();

            user.FullName = textBoxes["FullName"].Text;
            user.Email = textBoxes["Email"].Text;
            user.Phone = textBoxes["Phone"].Text;
            user.Role = textBoxes["Role"].Text;

            if (existingItem == null)
            {
                user.RegistrationDate = DateTime.Now;
            }

            return user;
        }

        private Booking GetBookingData()
        {
            var booking = existingItem as Booking ?? new Booking();

            if (int.TryParse(textBoxes["UserId"].Text, out int userId))
                booking.UserId = userId;

            if (int.TryParse(textBoxes["LocationId"].Text, out int locationId))
                booking.LocationId = locationId;

            if (int.TryParse(textBoxes["TotalGuests"].Text, out int guests))
                booking.TotalGuests = guests;

            if (decimal.TryParse(textBoxes["TotalPrice"].Text, out decimal price))
                booking.TotalPrice = price;

            if (datePickers["CheckInDate"].SelectedDate.HasValue)
                booking.CheckInDate = datePickers["CheckInDate"].SelectedDate.Value;

            if (datePickers["CheckOutDate"].SelectedDate.HasValue)
                booking.CheckOutDate = datePickers["CheckOutDate"].SelectedDate.Value;

            return booking;
        }

        private Location GetLocationData()
        {
            var location = existingItem as Location ?? new Location();

            location.Name = textBoxes["Name"].Text;
            location.Region = textBoxes["Region"].Text;
            location.Address = textBoxes["Address"].Text;

            if (decimal.TryParse(textBoxes["Price"].Text, out decimal price))
                location.Price = price;

            return location;
        }

        private Service GetServiceData()
        {
            var service = existingItem as Service ?? new Service();

            service.Name = textBoxes["Name"].Text;
            service.Description = textBoxes["Description"].Text;

            return service;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateForm())
            {
                DialogResult = true;
                Close();
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private bool ValidateForm()
        {
            switch (tableName)
            {
                case "Users":
                    return ValidateUserForm();
                case "Bookings":
                    return ValidateBookingForm();
                case "Locations":
                    return ValidateLocationForm();
                case "Services":
                    return ValidateServiceForm();
                default:
                    return false;
            }
        }

        private bool ValidateUserForm()
        {
            if (string.IsNullOrWhiteSpace(textBoxes["FullName"].Text))
            {
                MessageBox.Show("Имя пользователя не может быть пустым", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(textBoxes["Email"].Text) ||
                !textBoxes["Email"].Text.Contains("@"))
            {
                MessageBox.Show("Введите корректный email", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        private bool ValidateBookingForm()
        {
            if (!int.TryParse(textBoxes["UserId"].Text, out _))
            {
                MessageBox.Show("ID пользователя должен быть числом", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (!int.TryParse(textBoxes["LocationId"].Text, out _))
            {
                MessageBox.Show("ID локации должен быть числом", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (!int.TryParse(textBoxes["TotalGuests"].Text, out int guests) || guests <= 0)
            {
                MessageBox.Show("Количество гостей должно быть положительным числом",
                    "Ошибка валидации", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (!decimal.TryParse(textBoxes["TotalPrice"].Text, out decimal price) || price <= 0)
            {
                MessageBox.Show("Цена должна быть положительным числом", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (!datePickers["CheckInDate"].SelectedDate.HasValue ||
                !datePickers["CheckOutDate"].SelectedDate.HasValue)
            {
                MessageBox.Show("Выберите даты заезда и выезда", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (datePickers["CheckOutDate"].SelectedDate <= datePickers["CheckInDate"].SelectedDate)
            {
                MessageBox.Show("Дата выезда должна быть позже даты заезда", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        private bool ValidateLocationForm()
        {
            if (string.IsNullOrWhiteSpace(textBoxes["Name"].Text))
            {
                MessageBox.Show("Название локации не может быть пустым", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (!decimal.TryParse(textBoxes["Price"].Text, out decimal price) || price <= 0)
            {
                MessageBox.Show("Цена должна быть положительным числом", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        private bool ValidateServiceForm()
        {
            if (string.IsNullOrWhiteSpace(textBoxes["Name"].Text))
            {
                MessageBox.Show("Название услуги не может быть пустым", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }
    }
}