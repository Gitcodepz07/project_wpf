﻿// Views/LoginWindow.xaml.cs
using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using WpfApp1.Services;
using WpfApp1.ViewModels;

namespace WpfApp1.Views
{
    public partial class LoginWindow : Window
    {
        private readonly DatabaseService databaseService;

        public LoginWindow()
        {
            InitializeComponent();
            databaseService = new DatabaseService();
            Loaded += LoginWindow_Loaded;
        }

        private async void LoginWindow_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                await databaseService.InitializeAsync();
                ErrorText.Text = "Подключение установлено";
                ErrorText.Foreground = Brushes.Green;
            }
            catch (Exception ex)
            {
                ErrorText.Text = $"Ошибка подключения: {ex.Message}";
                ErrorText.Foreground = Brushes.Red;
            }
        }

        private async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                ErrorText.Text = string.Empty;
                ErrorText.Foreground = Brushes.Red;

                var email = EmailTextBox.Text?.Trim();
                var password = PasswordBox.Password;

                if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
                {
                    ErrorText.Text = "Заполните все поля";
                    return;
                }

                LoginButton.IsEnabled = false;
                LoginButton.Content = "Выполняется вход...";

                var success = await databaseService.SignInAsync(email, password);

                if (success)
                {
                    var mainWindow = new MainWindow();
                    var viewModel = new AdminViewModel(databaseService);
                    mainWindow.SetViewModel(viewModel);
                    mainWindow.Show();
                    this.Close();
                }
                else
                {
                    ErrorText.Text = "Неверный email или пароль";
                }
            }
            catch (Exception ex)
            {
                ErrorText.Text = $"Ошибка: {ex.Message}";
            }
            finally
            {
                LoginButton.IsEnabled = true;
                LoginButton.Content = "Войти";
            }
        }
    }
}