﻿
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using WpfApp1.Models;
using WpfApp1.Services;
using WpfApp1.Views;

namespace WpfApp1.ViewModels
{
    public class AdminViewModel : BaseViewModel
    {
        private readonly DatabaseService databaseService;

        
        public ObservableCollection<User> Users { get; set; } = new ObservableCollection<User>();
        public ObservableCollection<Booking> Bookings { get; set; } = new ObservableCollection<Booking>();
        public ObservableCollection<Location> Locations { get; set; } = new ObservableCollection<Location>();
        public ObservableCollection<Service> Services { get; set; } = new ObservableCollection<Service>();

      
        private List<User> allUsers = new List<User>();
        private List<Booking> allBookings = new List<Booking>();
        private List<Location> allLocations = new List<Location>();
        private List<Service> allServices = new List<Service>();

       
        private string searchText;
        public string SearchText
        {
            get => searchText;
            set
            {
                if (SetProperty(ref searchText, value))
                {
                    ApplyFilters();
                }
            }
        }

        private string selectedTable;
        public string SelectedTable
        {
            get => selectedTable;
            set
            {
                if (SetProperty(ref selectedTable, value))
                {
                    OnPropertyChanged(nameof(IsTableSelected));
                  
                    _ = LoadDataAsync();
                }
            }
        }

        public bool IsTableSelected => !string.IsNullOrEmpty(SelectedTable);

        
        private object selectedItem;
        public object SelectedItem
        {
            get => selectedItem;
            set
            {
                if (SetProperty(ref selectedItem, value))
                {
                    OnPropertyChanged(nameof(IsItemSelected));
                    // Обновляем состояние команд
                    CommandManager.InvalidateRequerySuggested();
                }
            }
        }

        public bool IsItemSelected => SelectedItem != null;

        
        public ICommand LoadDataCommand { get; }
        public ICommand AddCommand { get; }
        public ICommand EditCommand { get; }
        public ICommand DeleteCommand { get; }
        public ICommand SearchCommand { get; }
        public ICommand ClearSearchCommand { get; }
        public ICommand SelectTableCommand { get; }

        
        public object CurrentTableData
        {
            get
            {
                switch (SelectedTable)
                {
                    case "Users": return Users;
                    case "Bookings": return Bookings;
                    case "Locations": return Locations;
                    case "Services": return Services;
                    default: return null;
                }
            }
        }

        public AdminViewModel(DatabaseService dbService)
        {
            databaseService = dbService;

            LoadDataCommand = new RelayCommand(async _ => await LoadDataAsync());
            AddCommand = new RelayCommand(async _ => await AddItemAsync(), _ => IsTableSelected);
            EditCommand = new RelayCommand(async _ => await EditItemAsync(), _ => IsItemSelected);
            DeleteCommand = new RelayCommand(async _ => await DeleteItemAsync(), _ => IsItemSelected);
            SearchCommand = new RelayCommand(_ => ApplyFilters());
            ClearSearchCommand = new RelayCommand(_ => ClearSearch());
            SelectTableCommand = new RelayCommand(async param => await SelectTableAsync(param?.ToString()));
        }

        private async Task SelectTableAsync(string tableName)
        {
            if (string.IsNullOrEmpty(tableName)) return;

            SelectedTable = tableName;
            SearchText = string.Empty; 
            await LoadDataAsync();
        }

        private async Task LoadDataAsync()
        {
            if (string.IsNullOrEmpty(SelectedTable)) return;

            try
            {
                switch (SelectedTable)
                {
                    case "Users":
                        var users = await databaseService.GetUsersAsync();
                        allUsers = users;
                        UpdateUsersCollection(allUsers);
                        break;

                    case "Bookings":
                        var bookings = await databaseService.GetBookingsAsync();
                        allBookings = bookings;
                        Bookings.Clear();
                        foreach (var booking in allBookings) Bookings.Add(booking);
                        break;

                    case "Locations":
                        var locations = await databaseService.GetLocationsAsync();
                        allLocations = locations;
                        Locations.Clear();
                        foreach (var location in allLocations) Locations.Add(location);
                        break;

                    case "Services":
                        var services = await databaseService.GetServicesAsync();
                        allServices = services;
                        Services.Clear();
                        foreach (var service in allServices) Services.Add(service);
                        break;
                }

                OnPropertyChanged(nameof(CurrentTableData));
            }
            catch (UnauthorizedAccessException)
            {
                MessageBox.Show("Сессия истекла. Пожалуйста, войдите снова.", "Ошибка авторизации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateUsersCollection(List<User> users)
        {
            Users.Clear();
            foreach (var user in users) Users.Add(user);
        }

        private void ApplyFilters()
        {
            if (string.IsNullOrWhiteSpace(SearchText))
            {
               
                ResetToAllData();
                return;
            }

            switch (SelectedTable)
            {
                case "Users":
                    var filteredUsers = allUsers.Where(u =>
                        (u.FullName?.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ?? false) ||
                        (u.Email?.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ?? false) ||
                        (u.Phone?.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ?? false) ||
                        (u.Role?.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ?? false)
                    ).ToList();
                    UpdateUsersCollection(filteredUsers);
                    break;

                case "Bookings":
                    var filteredBookings = allBookings.Where(b =>
                        b.UserId.ToString().Contains(SearchText) ||
                        b.LocationId.ToString().Contains(SearchText) ||
                        b.TotalGuests.ToString().Contains(SearchText) ||
                        b.TotalPrice.ToString().Contains(SearchText)
                    ).ToList();
                    Bookings.Clear();
                    foreach (var booking in filteredBookings) Bookings.Add(booking);
                    break;

                case "Locations":
                    var filteredLocations = allLocations.Where(l =>
                        (l.Name?.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ?? false) ||
                        (l.Region?.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ?? false) ||
                        (l.Address?.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ?? false)
                    ).ToList();
                    Locations.Clear();
                    foreach (var location in filteredLocations) Locations.Add(location);
                    break;

                case "Services":
                    var filteredServices = allServices.Where(s =>
                        (s.Name?.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ?? false) ||
                        (s.Description?.Contains(SearchText, StringComparison.OrdinalIgnoreCase) ?? false)
                    ).ToList();
                    Services.Clear();
                    foreach (var service in filteredServices) Services.Add(service);
                    break;
            }

            OnPropertyChanged(nameof(CurrentTableData));
        }

        private void ClearSearch()
        {
            SearchText = string.Empty;
            ResetToAllData();
        }

        private void ResetToAllData()
        {
            switch (SelectedTable)
            {
                case "Users":
                    UpdateUsersCollection(allUsers);
                    break;
                case "Bookings":
                    Bookings.Clear();
                    foreach (var booking in allBookings) Bookings.Add(booking);
                    break;
                case "Locations":
                    Locations.Clear();
                    foreach (var location in allLocations) Locations.Add(location);
                    break;
                case "Services":
                    Services.Clear();
                    foreach (var service in allServices) Services.Add(service);
                    break;
            }
            OnPropertyChanged(nameof(CurrentTableData));
        }

        private async Task AddItemAsync()
        {
            if (string.IsNullOrEmpty(SelectedTable))
            {
                MessageBox.Show("Выберите таблицу", "Предупреждение",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var dialog = new EditDialog(SelectedTable);
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    var data = dialog.GetData();

                    switch (SelectedTable)
                    {
                        case "Users":
                            var newUser = data as User;
                            if (newUser != null && ValidateUser(newUser))
                            {
                                await databaseService.CreateUserAsync(newUser);
                                await LoadDataAsync();
                                MessageBox.Show("Пользователь успешно добавлен", "Успех",
                                    MessageBoxButton.OK, MessageBoxImage.Information);
                            }
                            break;

                        case "Bookings":
                            var newBooking = data as Booking;
                            if (newBooking != null && ValidateBooking(newBooking))
                            {
                                await databaseService.CreateBookingAsync(newBooking);
                                await LoadDataAsync();
                            }
                            break;

                        case "Locations":
                            var newLocation = data as Location;
                            if (newLocation != null && ValidateLocation(newLocation))
                            {
                                await databaseService.CreateLocationAsync(newLocation);
                                await LoadDataAsync();
                            }
                            break;

                        case "Services":
                            var newService = data as Service;
                            if (newService != null && ValidateService(newService))
                            {
                                await databaseService.CreateServiceAsync(newService);
                                await LoadDataAsync();
                            }
                            break;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка добавления: {ex.Message}", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private async Task EditItemAsync()
        {
            if (SelectedItem == null) return;

            var dialog = new EditDialog(SelectedTable, SelectedItem);
            if (dialog.ShowDialog() == true)
            {
                try
                {
                    var data = dialog.GetData();

                    switch (SelectedTable)
                    {
                        case "Users":
                            var updatedUser = data as User;
                            if (updatedUser != null && ValidateUser(updatedUser))
                            {
                                await databaseService.UpdateUserAsync(updatedUser);
                                await LoadDataAsync();
                            }
                            break;

                        case "Bookings":
                            var updatedBooking = data as Booking;
                            if (updatedBooking != null && ValidateBooking(updatedBooking))
                            {
                                await databaseService.UpdateBookingAsync(updatedBooking);
                                await LoadDataAsync();
                            }
                            break;

                        case "Locations":
                            var updatedLocation = data as Location;
                            if (updatedLocation != null && ValidateLocation(updatedLocation))
                            {
                                await databaseService.UpdateLocationAsync(updatedLocation);
                                await LoadDataAsync();
                            }
                            break;

                        case "Services":
                            var updatedService = data as Service;
                            if (updatedService != null && ValidateService(updatedService))
                            {
                                await databaseService.UpdateServiceAsync(updatedService);
                                await LoadDataAsync();
                            }
                            break;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка обновления: {ex.Message}", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private async Task DeleteItemAsync()
        {
            if (SelectedItem == null) return;

            var result = MessageBox.Show("Вы уверены, что хотите удалить запись?",
                "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                try
                {
                    switch (SelectedTable)
                    {
                        case "Users":
                            var user = SelectedItem as User;
                            await databaseService.DeleteUserAsync(user.Id);
                            break;

                        case "Bookings":
                            var booking = SelectedItem as Booking;
                            await databaseService.DeleteBookingAsync(booking.Id);
                            break;

                        case "Locations":
                            var location = SelectedItem as Location;
                            await databaseService.DeleteLocationAsync(location.Id);
                            break;

                        case "Services":
                            var service = SelectedItem as Service;
                            await databaseService.DeleteServiceAsync(service.Id);
                            break;
                    }

                    await LoadDataAsync();
                    SelectedItem = null;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка удаления: {ex.Message}", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        
        private bool ValidateUser(User user)
        {
            if (string.IsNullOrWhiteSpace(user.FullName))
            {
                MessageBox.Show("Имя пользователя не может быть пустым", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(user.Email) || !user.Email.Contains("@"))
            {
                MessageBox.Show("Некорректный email", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        private bool ValidateBooking(Booking booking)
        {
            if (booking.UserId <= 0)
            {
                MessageBox.Show("ID пользователя должен быть положительным числом", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (booking.LocationId <= 0)
            {
                MessageBox.Show("ID локации должен быть положительным числом", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (booking.TotalGuests <= 0)
            {
                MessageBox.Show("Количество гостей должно быть положительным числом", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (booking.TotalPrice <= 0)
            {
                MessageBox.Show("Цена должна быть положительным числом", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (booking.CheckInDate >= booking.CheckOutDate)
            {
                MessageBox.Show("Дата выезда должна быть позже даты заезда", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        private bool ValidateLocation(Location location)
        {
            if (string.IsNullOrWhiteSpace(location.Name))
            {
                MessageBox.Show("Название локации не может быть пустым", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            if (location.Price <= 0)
            {
                MessageBox.Show("Цена должна быть положительным числом", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        private bool ValidateService(Service service)
        {
            if (string.IsNullOrWhiteSpace(service.Name))
            {
                MessageBox.Show("Название услуги не может быть пустым", "Ошибка валидации",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }
    }
}