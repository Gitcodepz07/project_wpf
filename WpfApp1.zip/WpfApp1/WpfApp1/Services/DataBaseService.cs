﻿// Services/DatabaseService.cs
using Supabase;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WpfApp1.Models;

namespace WpfApp1.Services
{
    public class DatabaseService
    {
        private Client supabase;
        private bool isAuthenticated = false;

        public async Task InitializeAsync()
        {
            var url = "https://fjdelmitiabcwyzzjtjy.supabase.co";
            var key = "sb_publishable_sY15WN4JKq9IljgPAyVfvg_mp3epn0R";

            var options = new SupabaseOptions
            {
                AutoConnectRealtime = false
            };

            supabase = new Client(url, key, options);
            await supabase.InitializeAsync();
        }

        public async Task<bool> SignInAsync(string email, string password)
        {
            try
            {
                var session = await supabase.Auth.SignIn(email, password);

                if (session != null)
                {
                    isAuthenticated = true;

                   
                    await supabase.Auth.SetSession(session.AccessToken, session.RefreshToken);

                    System.Diagnostics.Debug.WriteLine($"Токен установлен: {session.AccessToken?.Substring(0, 20)}...");

                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка входа: {ex.Message}");
                return false;
            }
        }

        #region Users CRUD
        public async Task<List<User>> GetUsersAsync()
        {
            try
            {
                System.Diagnostics.Debug.WriteLine("Запрос пользователей...");

                var result = await supabase.From<User>().Get();

                System.Diagnostics.Debug.WriteLine($"Получено: {result.Models?.Count ?? 0} пользователей");

                return result.Models ?? new List<User>();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Ошибка получения пользователей: {ex.Message}");
                throw;
            }
        }

        public async Task<User> CreateUserAsync(User user)
        {
            var result = await supabase.From<User>().Insert(user);
            return result.Models?.FirstOrDefault();
        }

        public async Task UpdateUserAsync(User user)
        {
            await user.Update<User>();
        }

        public async Task DeleteUserAsync(int id)
        {
            await supabase.From<User>().Where(u => u.Id == id).Delete();
        }
        #endregion

        #region Bookings CRUD
        public async Task<List<Booking>> GetBookingsAsync()
        {
            var result = await supabase.From<Booking>().Get();
            return result.Models ?? new List<Booking>();
        }

        public async Task<Booking> CreateBookingAsync(Booking booking)
        {
            var result = await supabase.From<Booking>().Insert(booking);
            return result.Models?.FirstOrDefault();
        }

        public async Task UpdateBookingAsync(Booking booking)
        {
            await booking.Update<Booking>();
        }

        public async Task DeleteBookingAsync(int id)
        {
            await supabase.From<Booking>().Where(b => b.Id == id).Delete();
        }
        #endregion

        #region Locations CRUD
        public async Task<List<Location>> GetLocationsAsync()
        {
            var result = await supabase.From<Location>().Get();
            return result.Models ?? new List<Location>();
        }

        public async Task<Location> CreateLocationAsync(Location location)
        {
            var result = await supabase.From<Location>().Insert(location);
            return result.Models?.FirstOrDefault();
        }

        public async Task UpdateLocationAsync(Location location)
        {
            await location.Update<Location>();
        }

        public async Task DeleteLocationAsync(int id)
        {
            await supabase.From<Location>().Where(l => l.Id == id).Delete();
        }
        #endregion

        #region Services CRUD
        public async Task<List<Service>> GetServicesAsync()
        {
            var result = await supabase.From<Service>().Get();
            return result.Models ?? new List<Service>();
        }

        public async Task<Service> CreateServiceAsync(Service service)
        {
            var result = await supabase.From<Service>().Insert(service);
            return result.Models?.FirstOrDefault();
        }

        public async Task UpdateServiceAsync(Service service)
        {
            await service.Update<Service>();
        }

        public async Task DeleteServiceAsync(int id)
        {
            await supabase.From<Service>().Where(s => s.Id == id).Delete();
        }
        #endregion
    }
}