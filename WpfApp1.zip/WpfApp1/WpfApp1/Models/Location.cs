﻿using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Models
{
    [Table("locations")]
    public class Location : BaseModel
    {
        [PrimaryKey("id")]
        public int Id { get; set; }

        [Column("name")]
        public string Name { get; set; }

        [Column("region")]
        public string Region { get; set; }

        [Column("adress")]
        public string Address { get; set; }

        [Column("price")]
        public decimal Price { get; set; }
    }
}