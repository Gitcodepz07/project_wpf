﻿using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Models
{
    [Table("bookings")]
    public class Booking : BaseModel
    {
        internal User? User;
        internal Location? Location;

        [PrimaryKey("id")]
        public int Id { get; set; }

        [Column("user_id")]
        public int UserId { get; set; }

        [Column("location_id")]
        public int LocationId { get; set; }

        [Column("check_in_date")]
        public DateTime CheckInDate { get; set; }

        [Column("check_out_date")]
        public DateTime CheckOutDate { get; set; }

        [Column("total_guests")]
        public int TotalGuests { get; set; }

        [Column("total_price")]
        public decimal TotalPrice { get; set; }
    }
}