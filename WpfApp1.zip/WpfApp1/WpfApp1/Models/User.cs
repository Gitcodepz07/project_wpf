﻿using Supabase.Postgrest.Attributes;
using Supabase.Postgrest.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace WpfApp1.Models
{
    [Table("Users")]
    public class User : BaseModel
    {
        [PrimaryKey("id")]
        public int Id { get; set; }

        [Column("full_name")]
        public string FullName { get; set; }

        [Column("email")]
        public string Email { get; set; }

        [Column("phone")]
        public string Phone { get; set; }

        [Column("registration_date")]
        public DateTime RegistrationDate { get; set; }

        [Column("role")]
        public string Role { get; set; }

        // Используем существующую колонку password
        [Column("password")]
        public string Password { get; set; }
    }
}