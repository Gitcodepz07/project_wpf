﻿// App.xaml.cs
using System.Windows;
using WpfApp1.Views;

namespace WpfApp1
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Обработка необработанных исключений
            this.DispatcherUnhandledException += (s, args) =>
            {
                MessageBox.Show($"Произошла ошибка: {args.Exception.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                args.Handled = true;
            };

            // Запускаем окно авторизации
            var loginWindow = new LoginWindow();
            loginWindow.Show();
        }
    }
}